import { useState, useRef, useEffect } from "react";

const ORBITAL_COLORS: Record<string, string> = {
  s: "0,255,255",
  p: "124,58,237",
  d: "0,255,150",
};

const ORBITAL_INFO: Record<string, { electrons: number; shape: string }> = {
  s: { electrons: 2, shape: "Spherical" },
  p: { electrons: 6, shape: "Dumbbell" },
  d: { electrons: 10, shape: "Complex" },
};

interface Electron {
  theta: number;
  phi: number;
  speed: number;
  r: number;
  size: number;
}

export default function ElectronOrbital() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const startRef = useRef<number | null>(null);
  const [n, setN] = useState(2);
  const [orbitalType, setOrbitalType] = useState<"s" | "p" | "d">("s");
  const electronsRef = useRef<Electron[]>([]);

  useEffect(() => {
    const numElectrons = n * 3 + 6;
    electronsRef.current = Array.from({ length: numElectrons }, (_, i) => ({
      theta: Math.random() * Math.PI * 2,
      phi: Math.random() * Math.PI,
      speed: (0.3 + Math.random() * 0.7) / n,
      r: 40 + n * 30 + Math.random() * 20,
      size: 3 + Math.random() * 3,
    }));
  }, [n, orbitalType]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const t = (ts - startRef.current) / 1000;

      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H / 2;
      const color = ORBITAL_COLORS[orbitalType];

      const numRings = n;
      for (let ring = 1; ring <= numRings; ring++) {
        const r = (ring / numRings) * (80 + n * 30);
        ctx.beginPath();
        ctx.ellipse(cx, cy, r, r * 0.35, t * 0.1, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${color},0.12)`;
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.beginPath();
        ctx.ellipse(cx, cy, r, r * 0.35, t * 0.1 + Math.PI / 2, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${color},0.08)`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      if (orbitalType === "p" || orbitalType === "d") {
        const lobes = orbitalType === "p" ? 2 : 4;
        for (let lobe = 0; lobe < lobes; lobe++) {
          const angle = (lobe / lobes) * Math.PI * 2 + t * 0.1;
          const lobeR = 30 + n * 18;
          const lobeCx = cx + Math.cos(angle) * lobeR;
          const lobeCy = cy + Math.sin(angle) * lobeR * 0.5;

          for (let j = 0; j < 60; j++) {
            const pr = Math.random() * lobeR * 0.6;
            const pa = Math.random() * Math.PI * 2;
            const px = lobeCx + Math.cos(pa) * pr;
            const py = lobeCy + Math.sin(pa) * pr * 0.5;
            const alpha = Math.max(0, 1 - pr / (lobeR * 0.6));
            ctx.beginPath();
            ctx.arc(px, py, 1.5, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${color},${alpha * 0.25})`;
            ctx.fill();
          }
        }
      } else {
        const baseR = 50 + n * 20;
        for (let j = 0; j < 120; j++) {
          const pr = Math.random() * baseR;
          const pa = Math.random() * Math.PI * 2;
          const tilt = 0.35;
          const px = cx + Math.cos(pa) * pr;
          const py = cy + Math.sin(pa) * pr * tilt;
          const alpha = Math.max(0, 1 - (pr / baseR) ** 1.5) * 0.4;
          ctx.beginPath();
          ctx.arc(px, py, 1.5, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${color},${alpha})`;
          ctx.fill();
        }
      }

      const nucleusGrd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 20);
      nucleusGrd.addColorStop(0, "rgba(255,80,80,1)");
      nucleusGrd.addColorStop(0.5, "rgba(200,30,30,0.7)");
      nucleusGrd.addColorStop(1, "rgba(150,0,0,0)");
      ctx.beginPath();
      ctx.arc(cx, cy, 20, 0, Math.PI * 2);
      ctx.fillStyle = nucleusGrd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fillStyle = "#ff5050";
      ctx.fill();
      ctx.fillStyle = "rgba(255,120,120,0.8)";
      ctx.font = "9px monospace";
      ctx.textAlign = "center";
      ctx.fillText(`n=${n}`, cx, cy + 3);

      electronsRef.current.forEach((e, i) => {
        const angle = e.theta + t * e.speed * (i % 2 === 0 ? 1 : -1);
        const tilt = orbitalType === "s" ? 0.35 : 0.2 + (i % 3) * 0.2;
        const ex = cx + Math.cos(angle) * e.r;
        const ey = cy + Math.sin(angle) * e.r * tilt;

        const eGrd = ctx.createRadialGradient(ex, ey, 0, ex, ey, e.size * 3);
        eGrd.addColorStop(0, `rgba(${color},1)`);
        eGrd.addColorStop(0.5, `rgba(${color},0.4)`);
        eGrd.addColorStop(1, `rgba(${color},0)`);
        ctx.beginPath();
        ctx.arc(ex, ey, e.size * 3, 0, Math.PI * 2);
        ctx.fillStyle = eGrd;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(ex, ey, e.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color},1)`;
        ctx.fill();
      });

      ctx.textAlign = "left";
      ctx.fillStyle = `rgba(${color},0.7)`;
      ctx.font = "12px monospace";
      ctx.fillText(`n=${n}  l=${orbitalType}  Orbital: ${n}${orbitalType}`, 16, 24);

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [n, orbitalType]);

  const info = ORBITAL_INFO[orbitalType];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Principal Quantum Number (n): {n}
            </label>
            <div className="flex gap-2">
              {[1, 2, 3, 4].map(v => (
                <button key={v} data-testid={`button-n-${v}`} onClick={() => setN(v)}
                  className={`flex-1 py-2 rounded font-mono text-sm transition-all border ${n === v ? "bg-cyan-500/30 border-cyan-400 text-cyan-300" : "border-slate-700 text-slate-400 hover:border-cyan-700"}`}>
                  {v}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Orbital Type
            </label>
            <div className="flex gap-2">
              {(["s", "p", "d"] as const).map(type => (
                <button key={type} data-testid={`button-orbital-${type}`} onClick={() => setOrbitalType(type)}
                  className={`flex-1 py-2 rounded font-mono text-sm uppercase transition-all border ${orbitalType === type ? "bg-violet-500/30 border-violet-400 text-violet-300" : "border-slate-700 text-slate-400 hover:border-violet-700"}`}>
                  {type}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 space-y-2">
            <div className="text-xs text-slate-400 font-mono">Max electrons: <span className="text-cyan-300">{info.electrons}</span></div>
            <div className="text-xs text-slate-400 font-mono">Shape: <span className="text-violet-300">{info.shape}</span></div>
            <div className="text-xs text-slate-400 font-mono">Shell: <span className="text-cyan-300">{n}{orbitalType}</span></div>
            <div className="text-xs text-slate-400 font-mono">Energy level: <span className="text-red-400">n={n}</span></div>
          </div>
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={380} data-testid="canvas-orbital"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Quantum Shell", value: `${n}${orbitalType}`, formula: "n = principal QN" },
          { label: "Max Electrons", value: `${info.electrons}`, formula: `2(2l+1)` },
          { label: "Energy", value: `E ∝ -1/n²`, formula: "Bohr model" },
        ].map(item => (
          <div key={item.label} className="bg-cyan-950/20 border border-cyan-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-cyan-600 font-mono mb-1">{item.formula}</div>
            <div className="text-xl font-bold text-cyan-300 font-mono">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
