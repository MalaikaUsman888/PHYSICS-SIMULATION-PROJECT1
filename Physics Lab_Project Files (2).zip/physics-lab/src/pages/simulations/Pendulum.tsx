import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

export default function Pendulum() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const stateRef = useRef({ angle: 0, omega: 0, t: 0 });
  const trailRef = useRef<Array<{ x: number; y: number }>>([]);
  const lastTsRef = useRef<number | null>(null);

  const [length, setLength] = useState(2.5);
  const [initAngle, setInitAngle] = useState(30);
  const [gravity, setGravity] = useState(9.8);

  useEffect(() => {
    stateRef.current = { angle: (initAngle * Math.PI) / 180, omega: 0, t: 0 };
    trailRef.current = [];
    lastTsRef.current = null;
  }, [length, initAngle, gravity]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      const dt = lastTsRef.current ? Math.min((ts - lastTsRef.current) / 1000, 0.02) : 0.016;
      lastTsRef.current = ts;

      const state = stateRef.current;
      const alpha = -(gravity / length) * Math.sin(state.angle);
      state.omega += alpha * dt;
      state.angle += state.omega * dt;
      state.t += dt;

      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const pivotX = W / 2;
      const pivotY = 60;
      const scale = Math.min((H - 100) / (length + 0.1), 140);
      const bobX = pivotX + Math.sin(state.angle) * length * scale;
      const bobY = pivotY + Math.cos(state.angle) * length * scale;

      trailRef.current.push({ x: bobX, y: bobY });
      if (trailRef.current.length > 120) trailRef.current.shift();

      if (trailRef.current.length > 1) {
        ctx.lineWidth = 2;
        for (let i = 1; i < trailRef.current.length; i++) {
          const alpha = i / trailRef.current.length;
          ctx.strokeStyle = `rgba(124,58,237,${alpha * 0.7})`;
          ctx.beginPath();
          ctx.moveTo(trailRef.current[i - 1].x, trailRef.current[i - 1].y);
          ctx.lineTo(trailRef.current[i].x, trailRef.current[i].y);
          ctx.stroke();
        }
      }

      ctx.beginPath();
      ctx.arc(pivotX, pivotY, 6, 0, Math.PI * 2);
      ctx.fillStyle = "#334155";
      ctx.fill();
      ctx.strokeStyle = "#00ffff";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.strokeStyle = "rgba(0,255,255,0.5)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(pivotX, pivotY);
      ctx.lineTo(bobX, bobY);
      ctx.stroke();

      const grd = ctx.createRadialGradient(bobX, bobY, 0, bobX, bobY, 20);
      grd.addColorStop(0, "rgba(0,255,255,1)");
      grd.addColorStop(0.5, "rgba(0,180,255,0.6)");
      grd.addColorStop(1, "rgba(0,50,200,0)");
      ctx.beginPath();
      ctx.arc(bobX, bobY, 20, 0, Math.PI * 2);
      ctx.fillStyle = grd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(bobX, bobY, 10, 0, Math.PI * 2);
      ctx.fillStyle = "#00ffff";
      ctx.fill();

      ctx.fillStyle = "rgba(0,255,255,0.6)";
      ctx.font = "12px monospace";
      ctx.fillText(`θ = ${((state.angle * 180) / Math.PI).toFixed(1)}°`, 20, 30);
      ctx.fillText(`ω = ${state.omega.toFixed(2)} rad/s`, 20, 50);

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [length, gravity]);

  const period = (2 * Math.PI * Math.sqrt(length / gravity)).toFixed(2);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Length: {length} m
            </label>
            <Slider data-testid="slider-length" min={0.5} max={5} step={0.1} value={[length]}
              onValueChange={([v]) => setLength(Math.round(v * 10) / 10)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Initial Angle: {initAngle}°
            </label>
            <Slider data-testid="slider-initangle" min={5} max={80} step={1} value={[initAngle]}
              onValueChange={([v]) => setInitAngle(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Gravity: {gravity} m/s²
            </label>
            <Slider data-testid="slider-pendulum-gravity" min={1} max={25} step={0.1} value={[gravity]}
              onValueChange={([v]) => setGravity(Math.round(v * 10) / 10)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={380} data-testid="canvas-pendulum"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Period", value: `${period} s`, formula: "T = 2π√(L/g)" },
          { label: "Length", value: `${length} m`, formula: "L" },
          { label: "Gravity", value: `${gravity} m/s²`, formula: "g" },
        ].map(item => (
          <div key={item.label} className="bg-cyan-950/20 border border-cyan-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-cyan-600 font-mono mb-1">{item.formula}</div>
            <div className="text-2xl font-bold text-cyan-300 font-mono">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
