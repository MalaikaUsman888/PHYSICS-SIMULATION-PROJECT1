import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

// ──────────────────────────────────────────────────────────────
// PHYSICS REFERENCE
//
// Standard Keplerian gravity: F = -GM/r²  (r̂)
// GR correction (leading order):
//   F = -GM/r² · (1 + α/r²)  (r̂)
// where α ≡ 3(GM)²/(c²) in SI, but here α is a free parameter.
//
// Effect: α > 0 → force is stronger at close approach (periapsis)
//       → orbit doesn't close → ellipse rotates forward (prograde)
//       → produces "rosette" orbital pattern
//
// Mercury in GR: precesses ~43 arcsec/century (prograde).
// This simulation uses Euler-Cromer (symplectic Euler) integration,
// which conserves energy well for long runs.
//
// Units: dimensionless. GM = 1, a = 1.5 (semi-major axis).
// Periapsis: r_p = a(1-e),  Apoapsis: r_a = a(1+e)
// Speed at apoapsis: v_a = √(GM(1-e) / (a(1+e)))
// ──────────────────────────────────────────────────────────────

const GM    = 1.0;    // gravitational parameter (normalised)
const A_SMA = 1.5;    // semi-major axis (AU)
const SCALE = 85;     // pixels per AU
const DT    = 0.035;  // base time step per frame (years)
const MAX_TRAIL = 3500;

interface OrbState {
  x: number; y: number;
  vx: number; vy: number;
  t: number;
}

interface PeriInfo {
  angle: number; // radians, direction of perihelion
}

export default function OrbitalPrecession() {
  const canvasRef        = useRef<HTMLCanvasElement>(null);
  const animRef          = useRef<number>(0);
  const stateRef         = useRef<OrbState | null>(null);
  const trailRef         = useRef<Array<{ x: number; y: number }>>([]);
  const prevRRef         = useRef<number>(0);
  const orbitCountRef    = useRef<number>(0);
  const periInfoRef      = useRef<PeriInfo | null>(null);
  const totalPrecRef     = useRef<number>(0);  // accumulated precession (deg)
  const prevPeriAngleRef = useRef<number | null>(null);

  const [eccentricity, setEccentricity] = useState(0.50);
  const [alpha,        setAlpha]        = useState(0.030);
  const [speed,        setSpeed]        = useState(2);

  // ── Initialise / reinitialise when params change ─────────────
  useEffect(() => {
    const r_a = A_SMA * (1 + eccentricity);
    // Speed at apoapsis (Vis-viva + angular momentum conservation)
    const v_a = Math.sqrt(GM * (1 - eccentricity) / (A_SMA * (1 + eccentricity)));

    // Start at apoapsis (rightmost point): x = r_a, y = 0
    // Counterclockwise orbit: velocity in +y direction at apoapsis
    stateRef.current = { x: r_a, y: 0, vx: 0, vy: v_a, t: 0 };
    trailRef.current  = [];
    prevRRef.current  = r_a;
    orbitCountRef.current    = 0;
    periInfoRef.current      = null;
    totalPrecRef.current     = 0;
    prevPeriAngleRef.current = null;
  }, [eccentricity, alpha]);

  // ── Animation loop ────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W  = canvas.width;
    const H  = canvas.height;
    const CX = W / 2;
    const CY = H / 2;

    const draw = () => {
      const state = stateRef.current;
      if (!state) { animRef.current = requestAnimationFrame(draw); return; }

      // ── Integrate physics ──────────────────────────────────────
      const steps = speed * 3;
      let prevR = prevRRef.current;

      for (let s = 0; s < steps; s++) {
        const r2 = state.x * state.x + state.y * state.y;
        const r  = Math.sqrt(r2);
        if (r < 0.03) break; // avoid singularity near star

        // Force magnitude per unit mass: GM/r² · (1 + α/r²)
        const fMag = GM / (r2) * (1 + alpha / r2);
        const ax   = -fMag * state.x / r;
        const ay   = -fMag * state.y / r;

        // Euler-Cromer (symplectic): update velocity first, then position
        state.vx += ax * DT;
        state.vy += ay * DT;
        state.x  += state.vx * DT;
        state.y  += state.vy * DT;
        state.t  += DT;

        const rNew = Math.sqrt(state.x * state.x + state.y * state.y);

        // ── Perihelion detection: local r minimum ────────────────
        // Condition: r is now increasing (rNew > prevR), and r is < a (not apoapsis)
        if (rNew > prevR && prevR < A_SMA) {
          // Record perihelion direction (angle of current position ≈ perihelion direction)
          const periAngle = Math.atan2(state.y, state.x);

          if (prevPeriAngleRef.current !== null) {
            // Compute change in perihelion angle
            let dAngle = periAngle - prevPeriAngleRef.current;
            // Normalise to (-π, π) — removing the full-orbit ~0 advance
            while (dAngle >  Math.PI) dAngle -= 2 * Math.PI;
            while (dAngle < -Math.PI) dAngle += 2 * Math.PI;
            totalPrecRef.current += dAngle * (180 / Math.PI);
            orbitCountRef.current++;
          }

          prevPeriAngleRef.current = periAngle;
          periInfoRef.current      = { angle: periAngle };
        }

        prevR = rNew;
        trailRef.current.push({ x: state.x, y: state.y });
        if (trailRef.current.length > MAX_TRAIL) trailRef.current.shift();
      }
      prevRRef.current = prevR;

      // ── Render ─────────────────────────────────────────────────
      ctx.clearRect(0, 0, W, H);

      // Background circular grid
      ctx.lineWidth = 1;
      for (let rGrid = 40; rGrid < 320; rGrid += 55) {
        ctx.beginPath();
        ctx.arc(CX, CY, rGrid, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(0,255,255,0.04)";
        ctx.stroke();
      }
      // Cross hairs
      ctx.strokeStyle = "rgba(0,255,255,0.06)";
      ctx.beginPath(); ctx.moveTo(CX, 0);   ctx.lineTo(CX, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, CY);   ctx.lineTo(W, CY); ctx.stroke();

      // ── Trail ────────────────────────────────────────────────
      const trail = trailRef.current;
      const tLen  = trail.length;
      if (tLen > 1) {
        // Draw older trail in dim violet
        ctx.lineWidth = 1.2;
        const splitAt = Math.max(0, tLen - 250);

        // Old trail (dim)
        ctx.beginPath();
        for (let i = 0; i < splitAt; i++) {
          const tx = CX + trail[i].x * SCALE;
          const ty = CY - trail[i].y * SCALE;
          i === 0 ? ctx.moveTo(tx, ty) : ctx.lineTo(tx, ty);
        }
        ctx.strokeStyle = "rgba(90,30,180,0.30)";
        ctx.stroke();

        // Recent trail (bright)
        ctx.beginPath();
        for (let i = splitAt; i < tLen; i++) {
          const tx = CX + trail[i].x * SCALE;
          const ty = CY - trail[i].y * SCALE;
          i === splitAt ? ctx.moveTo(tx, ty) : ctx.lineTo(tx, ty);
        }
        ctx.lineWidth = 2;
        ctx.strokeStyle = "rgba(140,60,255,0.75)";
        ctx.stroke();
      }

      // ── Perihelion direction indicator ────────────────────────
      if (periInfoRef.current) {
        const pa   = periInfoRef.current.angle;
        const r_p  = A_SMA * (1 - eccentricity);
        const pLen = r_p * SCALE + 18;
        ctx.strokeStyle = "rgba(255,80,80,0.45)";
        ctx.lineWidth   = 1.5;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.moveTo(CX, CY);
        ctx.lineTo(CX + Math.cos(pa) * pLen, CY - Math.sin(pa) * pLen);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle   = "rgba(255,100,100,0.6)";
        ctx.font        = "10px monospace";
        ctx.textAlign   = "center";
        const lx = CX + Math.cos(pa) * (pLen + 22);
        const ly = CY - Math.sin(pa) * (pLen + 22);
        ctx.fillText("perihelion", lx, ly);
      }

      // ── Apoapsis direction indicator (dashed) ─────────────────
      if (periInfoRef.current) {
        const pa_apo = periInfoRef.current.angle + Math.PI;
        const r_a    = A_SMA * (1 + eccentricity);
        const aLen   = r_a * SCALE - 14;
        ctx.strokeStyle = "rgba(100,200,255,0.20)";
        ctx.lineWidth   = 1;
        ctx.setLineDash([3, 7]);
        ctx.beginPath();
        ctx.moveTo(CX, CY);
        ctx.lineTo(CX + Math.cos(pa_apo) * aLen, CY - Math.sin(pa_apo) * aLen);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // ── Star ──────────────────────────────────────────────────
      const starGrd = ctx.createRadialGradient(CX, CY, 0, CX, CY, 28);
      starGrd.addColorStop(0,   "rgba(255,220,60,1)");
      starGrd.addColorStop(0.4, "rgba(255,160,20,0.7)");
      starGrd.addColorStop(1,   "rgba(255,100,0,0)");
      ctx.beginPath();
      ctx.arc(CX, CY, 28, 0, Math.PI * 2);
      ctx.fillStyle = starGrd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(CX, CY, 9, 0, Math.PI * 2);
      ctx.fillStyle = "#ffd700";
      ctx.fill();

      // ── Planet ────────────────────────────────────────────────
      const px = CX + state.x * SCALE;
      const py = CY - state.y * SCALE;
      const planetGrd = ctx.createRadialGradient(px, py, 0, px, py, 16);
      planetGrd.addColorStop(0,   "rgba(0,255,255,1)");
      planetGrd.addColorStop(0.5, "rgba(0,140,255,0.5)");
      planetGrd.addColorStop(1,   "rgba(0,50,200,0)");
      ctx.beginPath();
      ctx.arc(px, py, 16, 0, Math.PI * 2);
      ctx.fillStyle = planetGrd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(px, py, 6, 0, Math.PI * 2);
      ctx.fillStyle = "#00ffff";
      ctx.fill();

      // ── HUD ──────────────────────────────────────────────────
      ctx.textAlign = "left";
      ctx.font      = "11px monospace";
      ctx.fillStyle = "rgba(0,255,255,0.65)";
      ctx.fillText(`Orbits completed: ${orbitCountRef.current}`, 14, 22);
      ctx.fillText(`Sim time: ${state.t.toFixed(1)} yr`,         14, 40);

      const precDeg = totalPrecRef.current;
      const precSign = precDeg >= 0 ? "+" : "";
      ctx.fillStyle = Math.abs(precDeg) > 0.5 ? "rgba(255,120,120,0.8)" : "rgba(180,180,180,0.5)";
      ctx.fillText(
        orbitCountRef.current > 0
          ? `Perihelion drift: ${precSign}${precDeg.toFixed(1)}°  (${precSign}${(precDeg / Math.max(orbitCountRef.current, 1)).toFixed(1)}°/orbit)`
          : "Perihelion drift: — (waiting for first orbit)",
        14, 58,
      );

      ctx.fillStyle = "rgba(100,255,150,0.50)";
      ctx.fillText(
        alpha === 0 ? "α = 0  → perfect Keplerian ellipse" : `α = ${alpha.toFixed(3)}  → GR-like forward precession`,
        14, 76,
      );

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [eccentricity, alpha, speed]); // eslint-disable-line react-hooks/exhaustive-deps

  const r_p = (A_SMA * (1 - eccentricity)).toFixed(2);
  const r_a = (A_SMA * (1 + eccentricity)).toFixed(2);
  const T   = (2 * Math.PI * Math.pow(A_SMA, 1.5) / Math.sqrt(GM)).toFixed(1);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="space-y-4">
          <div>
            <label className="text-xs text-violet-400 font-mono uppercase tracking-widest mb-2 block">
              Eccentricity: {eccentricity.toFixed(2)}
            </label>
            <Slider data-testid="slider-eccentricity"
              min={0.05} max={0.85} step={0.05} value={[eccentricity]}
              onValueChange={([v]) => setEccentricity(Math.round(v * 20) / 20)}
              className="[&_[role=slider]]:bg-violet-400" />
          </div>

          <div>
            <label className="text-xs text-violet-400 font-mono uppercase tracking-widest mb-2 block">
              Precession strength α: {alpha.toFixed(3)}
            </label>
            <Slider data-testid="slider-alpha"
              min={0} max={0.12} step={0.005} value={[alpha]}
              onValueChange={([v]) => setAlpha(Math.round(v * 200) / 200)}
              className="[&_[role=slider]]:bg-violet-400" />
          </div>

          <div>
            <label className="text-xs text-violet-400 font-mono uppercase tracking-widest mb-2 block">
              Simulation speed: {speed}×
            </label>
            <Slider data-testid="slider-orb-speed"
              min={1} max={8} step={1} value={[speed]}
              onValueChange={([v]) => setSpeed(v)}
              className="[&_[role=slider]]:bg-violet-400" />
          </div>

          {/* Orbital parameters */}
          <div className="rounded-xl border border-violet-900/30 bg-slate-900/40 p-3 space-y-1.5">
            <div className="text-xs text-violet-400 font-mono font-bold mb-2">Orbital parameters</div>
            {[
              ["Semi-major axis", `a = ${A_SMA} AU`],
              ["Eccentricity",   `e = ${eccentricity.toFixed(2)}`],
              ["Periapsis",      `r_p = ${r_p} AU`],
              ["Apoapsis",       `r_a = ${r_a} AU`],
              ["Keplerian period", `T = ${T} yr`],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between text-xs font-mono text-slate-400">
                <span>{k}</span>
                <span className="text-violet-300">{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Canvas */}
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={420}
            data-testid="canvas-precession"
            className="w-full rounded-xl border border-violet-900/40 bg-[#020818]" />
        </div>
      </div>

      {/* Info panels */}
      <div className="grid grid-cols-3 gap-4">
        {[
          {
            label:   "Force law",
            value:   "F = −GM/r²·(1+α/r²)",
            formula: "GR correction to Newtonian",
          },
          {
            label:   "Orbit pattern",
            value:   "Rosette (precessing ellipse)",
            formula: "α=0 → closed ellipse",
          },
          {
            label:   "Real example",
            value:   'Mercury: 43″/century',
            formula: "Confirmed by Einstein 1915",
          },
        ].map(item => (
          <div key={item.label}
            className="bg-violet-950/20 border border-violet-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-violet-600 font-mono mb-1">{item.formula}</div>
            <div className="text-sm font-bold text-violet-300 font-mono leading-snug">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
