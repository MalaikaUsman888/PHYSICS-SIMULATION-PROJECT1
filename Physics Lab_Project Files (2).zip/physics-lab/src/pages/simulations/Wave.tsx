import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

export default function Wave() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const startRef = useRef<number | null>(null);
  const [waveAmplitude, setWaveAmplitude] = useState(60);
  const [frequency, setFrequency] = useState(0.03);
  const [speed, setSpeed] = useState(3);
  const [twoSource, setTwoSource] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const t = (ts - startRef.current) / 1000;

      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      ctx.strokeStyle = "rgba(0,255,255,0.1)";
      ctx.lineWidth = 1;
      for (let i = 1; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(0, (H / 4) * i);
        ctx.lineTo(W, (H / 4) * i);
        ctx.stroke();
      }

      const k = frequency;
      const omega = frequency * speed * 2 * Math.PI;
      const cy1 = twoSource ? H / 3 : H / 2;
      const cy2 = (2 * H) / 3;

      const drawWave = (cy: number, phase: number, color: string) => {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        for (let x = 0; x < W; x++) {
          const y = cy + waveAmplitude * Math.sin(2 * Math.PI * k * x - omega * t + phase);
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
      };

      drawWave(cy1, 0, "rgba(0,255,255,0.8)");

      if (twoSource) {
        drawWave(cy2, Math.PI / 3, "rgba(124,58,237,0.8)");

        ctx.beginPath();
        ctx.strokeStyle = "rgba(0,255,180,0.9)";
        ctx.lineWidth = 2;
        for (let x = 0; x < W; x++) {
          const y1 = waveAmplitude * Math.sin(2 * Math.PI * k * x - omega * t);
          const y2 = waveAmplitude * Math.sin(2 * Math.PI * k * x - omega * t + Math.PI / 3);
          const combined = H / 2 + (y1 + y2) / 2;
          x === 0 ? ctx.moveTo(x, combined) : ctx.lineTo(x, combined);
        }
        ctx.stroke();
        ctx.fillStyle = "rgba(0,255,180,0.6)";
        ctx.font = "11px monospace";
        ctx.fillText("Resultant", 10, H / 2 - 8);
      }

      ctx.fillStyle = "rgba(0,255,255,0.6)";
      ctx.font = "11px monospace";
      ctx.fillText(`λ = ${(1 / k).toFixed(0)} px   v = ${speed}   f = ${frequency}`, 10, 20);

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [waveAmplitude, frequency, speed, twoSource]);

  const wavelength = Math.round(1 / frequency);
  const waveSpeed = speed;
  const waveFreq = Math.round(frequency * 100) / 100;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Amplitude: {waveAmplitude} px
            </label>
            <Slider data-testid="slider-wave-amplitude" min={10} max={100} step={1} value={[waveAmplitude]}
              onValueChange={([v]) => setWaveAmplitude(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Frequency: {frequency}
            </label>
            <Slider data-testid="slider-wave-frequency" min={0.005} max={0.08} step={0.001} value={[frequency]}
              onValueChange={([v]) => setFrequency(Math.round(v * 1000) / 1000)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Wave Speed: {speed}
            </label>
            <Slider data-testid="slider-wave-speed" min={0.5} max={10} step={0.5} value={[speed]}
              onValueChange={([v]) => setSpeed(Math.round(v * 2) / 2)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <button data-testid="button-two-source" onClick={() => setTwoSource(s => !s)}
            className={`w-full py-3 rounded-lg border font-mono text-sm uppercase tracking-widest transition-all ${twoSource ? "bg-violet-500/30 border-violet-400/60 text-violet-300" : "bg-violet-500/10 border-violet-500/30 text-violet-400"}`}>
            {twoSource ? "Two-Source ON" : "Two-Source OFF"}
          </button>
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={340} data-testid="canvas-wave"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Wavelength", value: `${wavelength} px`, formula: "λ = 1/k" },
          { label: "Wave Speed", value: `${waveSpeed}`, formula: "v = λf" },
          { label: "Equation", value: "y = A·sin(kx - ωt)", formula: "Wave equation" },
        ].map(item => (
          <div key={item.label} className="bg-cyan-950/20 border border-cyan-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-cyan-600 font-mono mb-1">{item.formula}</div>
            <div className="text-lg font-bold text-cyan-300 font-mono truncate">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
