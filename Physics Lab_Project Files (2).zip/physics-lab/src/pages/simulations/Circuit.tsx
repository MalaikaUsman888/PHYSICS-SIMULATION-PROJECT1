import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

export default function Circuit() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const startRef = useRef<number | null>(null);
  const [voltage, setVoltage] = useState(12);
  const [resistance, setResistance] = useState(100);

  const current = voltage / resistance;
  const power = voltage * current;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const t = (ts - startRef.current) / 1000;

      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H / 2;
      const rw = 200;
      const rh = 130;

      const tl = { x: cx - rw, y: cy - rh };
      const tr = { x: cx + rw, y: cy - rh };
      const br = { x: cx + rw, y: cy + rh };
      const bl = { x: cx - rw, y: cy + rh };

      ctx.strokeStyle = "rgba(0,255,255,0.25)";
      ctx.lineWidth = 6;
      ctx.lineJoin = "round";
      ctx.beginPath();
      ctx.moveTo(tl.x, tl.y);
      ctx.lineTo(tr.x, tr.y);
      ctx.lineTo(br.x, br.y);
      ctx.lineTo(bl.x, bl.y);
      ctx.lineTo(tl.x, tl.y);
      ctx.stroke();

      ctx.strokeStyle = "#00ffff";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(tl.x, tl.y);
      ctx.lineTo(tr.x, tr.y);
      ctx.lineTo(br.x, br.y);
      ctx.lineTo(bl.x, bl.y);
      ctx.lineTo(tl.x, tl.y);
      ctx.stroke();

      const battX = tl.x;
      const battY = cy;
      ctx.strokeStyle = "#00ffff";
      ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) {
        const y = battY - 20 + i * 20;
        const w = i % 2 === 0 ? 16 : 10;
        ctx.beginPath();
        ctx.moveTo(battX - w, y);
        ctx.lineTo(battX + w, y);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(0,255,255,0.7)";
      ctx.font = "12px monospace";
      ctx.textAlign = "center";
      ctx.fillText(`${voltage}V`, battX, battY + 45);

      const resX = cx;
      const resY = tr.y;
      const resLen = 80;
      const resH = 18;
      ctx.strokeStyle = "#7c3aed";
      ctx.lineWidth = 2;
      ctx.strokeRect(resX - resLen / 2, resY - resH, resLen, resH * 2);
      ctx.fillStyle = "rgba(124,58,237,0.15)";
      ctx.fillRect(resX - resLen / 2, resY - resH, resLen, resH * 2);
      ctx.fillStyle = "rgba(124,58,237,0.9)";
      ctx.font = "11px monospace";
      ctx.textAlign = "center";
      ctx.fillText(`${resistance}Ω`, resX, resY + 35);

      const bulbX = br.x;
      const bulbY = cy;
      const brightness = Math.min(power / 10, 1);
      const bulbGrd = ctx.createRadialGradient(bulbX, bulbY, 0, bulbX, bulbY, 30 + brightness * 20);
      bulbGrd.addColorStop(0, `rgba(255,230,50,${brightness})`);
      bulbGrd.addColorStop(0.5, `rgba(255,150,0,${brightness * 0.5})`);
      bulbGrd.addColorStop(1, "rgba(255,100,0,0)");
      ctx.beginPath();
      ctx.arc(bulbX, bulbY, 30 + brightness * 20, 0, Math.PI * 2);
      ctx.fillStyle = bulbGrd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(bulbX, bulbY, 15, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,220,30,${0.3 + brightness * 0.7})`;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,220,30,0.8)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = "rgba(255,220,30,0.8)";
      ctx.font = "11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("Load", bulbX, bulbY + 45);

      const numParticles = 12;
      const speed = Math.min(current * 8, 60);
      const totalLen = (rw * 2 + rh * 2) * 2;
      for (let i = 0; i < numParticles; i++) {
        const phase = ((i / numParticles) + (t * speed) / totalLen) % 1;
        const perimeter = 2 * (rw * 2 + rh * 2);
        const dist = phase * perimeter;
        let px = 0, py = 0;

        const seg1 = rw * 2;
        const seg2 = seg1 + rh * 2;
        const seg3 = seg2 + rw * 2;
        const seg4 = seg3 + rh * 2;

        if (dist < seg1) {
          px = tl.x + dist;
          py = tl.y;
        } else if (dist < seg2) {
          px = tr.x;
          py = tr.y + (dist - seg1);
        } else if (dist < seg3) {
          px = br.x - (dist - seg2);
          py = br.y;
        } else {
          px = bl.x;
          py = bl.y - (dist - seg3);
        }

        const alpha = 0.6 + 0.4 * Math.sin(i * 2.5);
        ctx.beginPath();
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,255,255,${alpha})`;
        ctx.fill();
      }

      ctx.textAlign = "left";
      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [voltage, resistance, current, power]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Voltage: {voltage} V
            </label>
            <Slider data-testid="slider-voltage" min={1} max={240} step={1} value={[voltage]}
              onValueChange={([v]) => setVoltage(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Resistance: {resistance} Ω
            </label>
            <Slider data-testid="slider-resistance" min={1} max={1000} step={1} value={[resistance]}
              onValueChange={([v]) => setResistance(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div className="bg-cyan-950/30 border border-cyan-900/30 rounded-lg p-3 space-y-2">
            <div className="text-xs text-cyan-400 font-mono">Ohm's Law: V = I × R</div>
            <div className="text-sm text-slate-300 font-mono">I = {current.toFixed(4)} A</div>
            <div className="text-xs text-cyan-400 font-mono mt-2">Power: P = V² / R</div>
            <div className="text-sm text-slate-300 font-mono">P = {power.toFixed(2)} W</div>
          </div>
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={340} data-testid="canvas-circuit"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Current", value: `${current.toFixed(4)} A`, formula: "I = V/R" },
          { label: "Power", value: `${power.toFixed(2)} W`, formula: "P = V²/R" },
          { label: "Energy/s", value: `${power.toFixed(2)} J/s`, formula: "P = I·V" },
        ].map(item => (
          <div key={item.label} className="bg-yellow-950/20 border border-yellow-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-yellow-600 font-mono mb-1">{item.formula}</div>
            <div className="text-xl font-bold text-yellow-300 font-mono">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
