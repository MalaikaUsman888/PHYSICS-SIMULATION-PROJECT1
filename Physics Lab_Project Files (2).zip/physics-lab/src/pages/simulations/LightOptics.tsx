import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

export default function LightOptics() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [incidenceAngle, setIncidenceAngle] = useState(40);
  const [n1, setN1] = useState(1.0);
  const [n2, setN2] = useState(1.5);

  const criticalAngle = n2 < n1 ? Math.asin(n2 / n1) * (180 / Math.PI) : null;
  const totalInternalReflection = criticalAngle !== null && incidenceAngle > criticalAngle;

  const refractedAngleDeg = (() => {
    const sinT2 = (n1 / n2) * Math.sin((incidenceAngle * Math.PI) / 180);
    if (Math.abs(sinT2) > 1) return null;
    return Math.asin(sinT2) * (180 / Math.PI);
  })();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const interfaceY = H / 2;
    const incidentX = W / 2;

    const grad1 = ctx.createLinearGradient(0, 0, 0, interfaceY);
    grad1.addColorStop(0, "rgba(0,40,80,0.6)");
    grad1.addColorStop(1, "rgba(0,80,160,0.4)");
    ctx.fillStyle = grad1;
    ctx.fillRect(0, 0, W, interfaceY);

    const grad2 = ctx.createLinearGradient(0, interfaceY, 0, H);
    grad2.addColorStop(0, "rgba(0,80,40,0.5)");
    grad2.addColorStop(1, "rgba(0,40,20,0.3)");
    ctx.fillStyle = grad2;
    ctx.fillRect(0, interfaceY, W, H - interfaceY);

    ctx.fillStyle = "rgba(0,200,255,0.3)";
    ctx.font = "13px monospace";
    ctx.textAlign = "center";
    ctx.fillText(`Medium 1  n₁ = ${n1.toFixed(2)}`, W / 4, interfaceY - 20);
    ctx.fillStyle = "rgba(0,255,160,0.4)";
    ctx.fillText(`Medium 2  n₂ = ${n2.toFixed(2)}`, (3 * W) / 4, interfaceY + 28);

    ctx.strokeStyle = "rgba(255,255,255,0.2)";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(incidentX, 20);
    ctx.lineTo(incidentX, H - 20);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(255,255,255,0.3)";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    ctx.fillText("Normal", incidentX, 18);

    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, interfaceY);
    ctx.lineTo(W, interfaceY);
    ctx.stroke();

    const angRad = (incidenceAngle * Math.PI) / 180;
    const rayLen = 220;
    const startX = incidentX - Math.sin(angRad) * rayLen;
    const startY = interfaceY - Math.cos(angRad) * rayLen;

    ctx.shadowColor = "rgba(255, 220, 0, 0.8)";
    ctx.shadowBlur = 12;
    ctx.strokeStyle = "#ffd700";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(incidentX, interfaceY);
    ctx.stroke();

    const arrowLen = 14;
    const arrowMidX = (startX + incidentX) / 2;
    const arrowMidY = (startY + interfaceY) / 2;
    const dx = incidentX - startX;
    const dy = interfaceY - startY;
    const norm = Math.sqrt(dx * dx + dy * dy);
    const ux = dx / norm, uy = dy / norm;
    const px = -uy, py = ux;
    ctx.beginPath();
    ctx.moveTo(arrowMidX + ux * arrowLen / 2, arrowMidY + uy * arrowLen / 2);
    ctx.lineTo(arrowMidX - ux * arrowLen / 2 + px * 6, arrowMidY - uy * arrowLen / 2 + py * 6);
    ctx.lineTo(arrowMidX - ux * arrowLen / 2 - px * 6, arrowMidY - uy * arrowLen / 2 - py * 6);
    ctx.closePath();
    ctx.fillStyle = "#ffd700";
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.shadowColor = "rgba(0, 180, 255, 0.8)";
    ctx.shadowBlur = 10;
    ctx.strokeStyle = "#00aaff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(incidentX, interfaceY);
    const refEndX = incidentX + Math.sin(angRad) * rayLen;
    const refEndY = interfaceY - Math.cos(angRad) * rayLen;
    ctx.lineTo(refEndX, refEndY);
    ctx.stroke();
    ctx.shadowBlur = 0;

    if (!totalInternalReflection && refractedAngleDeg !== null) {
      const refAngRad = (refractedAngleDeg * Math.PI) / 180;
      const refractEndX = incidentX + Math.sin(refAngRad) * rayLen;
      const refractEndY = interfaceY + Math.cos(refAngRad) * rayLen;
      ctx.shadowColor = "rgba(0, 255, 120, 0.8)";
      ctx.shadowBlur = 10;
      ctx.strokeStyle = "#00ff88";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(incidentX, interfaceY);
      ctx.lineTo(refractEndX, refractEndY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.strokeStyle = "rgba(0,255,136,0.3)";
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.arc(incidentX, interfaceY, 60, Math.PI / 2, Math.PI / 2 + refAngRad);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "rgba(0,255,136,0.7)";
      ctx.font = "11px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`θ₂ = ${refractedAngleDeg.toFixed(1)}°`, incidentX + 70, interfaceY + 55);
    }

    if (totalInternalReflection) {
      ctx.fillStyle = "rgba(255,80,80,0.9)";
      ctx.font = "bold 14px monospace";
      ctx.textAlign = "center";
      ctx.fillText("Total Internal Reflection", W / 2, interfaceY + 50);
    }

    ctx.strokeStyle = "rgba(255,215,0,0.35)";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.arc(incidentX, interfaceY, 60, Math.PI / 2 - angRad, Math.PI / 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(255,215,0,0.8)";
    ctx.font = "11px monospace";
    ctx.textAlign = "right";
    ctx.fillText(`θ₁ = ${incidenceAngle}°`, incidentX - 70, interfaceY - 45);

    ctx.fillStyle = "rgba(0,200,255,0.7)";
    ctx.font = "11px monospace";
    ctx.textAlign = "right";
    ctx.fillText(`θᵣ = ${incidenceAngle}°`, incidentX + 155, interfaceY - 45);

    const legendY = H - 20;
    ctx.textAlign = "left";
    [
      { color: "#ffd700", label: "Incident ray" },
      { color: "#00aaff", label: "Reflected ray" },
      { color: "#00ff88", label: "Refracted ray" },
    ].forEach(({ color, label }, i) => {
      ctx.fillStyle = color;
      ctx.fillRect(16 + i * 160, legendY - 8, 24, 3);
      ctx.fillStyle = "rgba(255,255,255,0.6)";
      ctx.font = "10px monospace";
      ctx.fillText(label, 46 + i * 160, legendY);
    });

  }, [incidenceAngle, n1, n2, totalInternalReflection, refractedAngleDeg]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Angle of Incidence: {incidenceAngle}°
            </label>
            <Slider data-testid="slider-incidence" min={0} max={89} step={1} value={[incidenceAngle]}
              onValueChange={([v]) => setIncidenceAngle(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Refractive Index n₁: {n1.toFixed(2)}
            </label>
            <Slider data-testid="slider-n1" min={1.0} max={2.5} step={0.05} value={[n1]}
              onValueChange={([v]) => setN1(Math.round(v * 20) / 20)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Refractive Index n₂: {n2.toFixed(2)}
            </label>
            <Slider data-testid="slider-n2" min={1.0} max={2.5} step={0.05} value={[n2]}
              onValueChange={([v]) => setN2(Math.round(v * 20) / 20)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          {criticalAngle !== null && (
            <div className="bg-red-950/20 border border-red-900/30 rounded-lg p-3">
              <div className="text-xs text-red-400 font-mono">Critical Angle</div>
              <div className="text-lg font-bold text-red-300 font-mono">{criticalAngle.toFixed(1)}°</div>
              {totalInternalReflection && (
                <div className="text-xs text-red-400 mt-1">Total Internal Reflection active!</div>
              )}
            </div>
          )}
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={380} data-testid="canvas-optics"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Snell's Law", value: `n₁sinθ₁ = n₂sinθ₂`, formula: "Refraction law" },
          { label: "Refracted Angle", value: totalInternalReflection ? "TIR" : refractedAngleDeg !== null ? `${refractedAngleDeg.toFixed(1)}°` : "—", formula: "θ₂ = arcsin(n₁sinθ₁/n₂)" },
          { label: "Critical Angle", value: criticalAngle !== null ? `${criticalAngle.toFixed(1)}°` : "N/A (n₁<n₂)", formula: "θc = arcsin(n₂/n₁)" },
        ].map(item => (
          <div key={item.label} className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-emerald-600 font-mono mb-1">{item.formula}</div>
            <div className="text-base font-bold text-emerald-300 font-mono">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
