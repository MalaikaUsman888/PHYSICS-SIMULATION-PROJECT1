import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

export default function SHM() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const startRef = useRef<number | null>(null);
  const [amplitude, setAmplitude] = useState(80);
  const [frequency, setFrequency] = useState(1.0);
  const [damping, setDamping] = useState(0.05);
  const [running, setRunning] = useState(true);
  const historyRef = useRef<number[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const t = (ts - startRef.current) / 1000;
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const omega = 2 * Math.PI * frequency;
      const x = amplitude * Math.exp(-damping * t) * Math.cos(omega * t);

      historyRef.current.push(x);
      if (historyRef.current.length > 400) historyRef.current.shift();

      const springX = 80;
      const bobY = H / 2;
      const equilibriumX = 300;
      const bobX = equilibriumX + x;

      ctx.strokeStyle = "rgba(0,255,255,0.15)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(equilibriumX, 20);
      ctx.lineTo(equilibriumX, H - 20);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 8;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(springX, bobY);
      const coils = 12;
      const coilWidth = 12;
      const dist = bobX - springX;
      for (let i = 0; i <= coils * 2; i++) {
        const cx = springX + (dist / (coils * 2)) * i;
        const cy = bobY + (i % 2 === 0 ? -coilWidth : coilWidth);
        i === 0 ? ctx.moveTo(cx, cy) : ctx.lineTo(cx, cy);
      }
      ctx.stroke();

      ctx.strokeStyle = "#00ffff";
      ctx.lineWidth = 3;
      ctx.beginPath();
      for (let i = 0; i <= coils * 2; i++) {
        const cx = springX + (dist / (coils * 2)) * i;
        const cy = bobY + (i % 2 === 0 ? -coilWidth : coilWidth);
        i === 0 ? ctx.moveTo(cx, cy) : ctx.lineTo(cx, cy);
      }
      ctx.stroke();

      const grd = ctx.createRadialGradient(bobX, bobY, 0, bobX, bobY, 22);
      grd.addColorStop(0, "rgba(0,255,255,1)");
      grd.addColorStop(0.5, "rgba(0,150,255,0.5)");
      grd.addColorStop(1, "rgba(0,50,180,0)");
      ctx.beginPath();
      ctx.arc(bobX, bobY, 22, 0, Math.PI * 2);
      ctx.fillStyle = grd;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(bobX, bobY, 12, 0, Math.PI * 2);
      ctx.fillStyle = "#00ffff";
      ctx.fill();

      const graphX = 440;
      const graphW = W - graphX - 20;
      const graphH = H - 40;
      const graphCy = H / 2;

      ctx.strokeStyle = "rgba(0,255,255,0.15)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(graphX, graphCy);
      ctx.lineTo(graphX + graphW, graphCy);
      ctx.stroke();

      ctx.strokeStyle = "#7c3aed";
      ctx.lineWidth = 2;
      ctx.beginPath();
      const history = historyRef.current;
      for (let i = 0; i < history.length; i++) {
        const px = graphX + (i / history.length) * graphW;
        const py = graphCy - (history[i] / 100) * (graphH / 2.5);
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
      }
      ctx.stroke();

      ctx.fillStyle = "rgba(0,255,255,0.6)";
      ctx.font = "11px monospace";
      ctx.fillText("Position Graph", graphX, 25);
      ctx.fillText(`x = ${x.toFixed(1)} m`, springX, H - 8);

      if (running) animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [amplitude, frequency, damping, running]);

  const reset = () => {
    historyRef.current = [];
    startRef.current = null;
    setRunning(true);
  };

  const period = (1 / frequency).toFixed(2);
  const omega = (2 * Math.PI * frequency).toFixed(2);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Amplitude: {amplitude} px
            </label>
            <Slider data-testid="slider-amplitude" min={10} max={150} step={1} value={[amplitude]}
              onValueChange={([v]) => { setAmplitude(v); reset(); }}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Frequency: {frequency} Hz
            </label>
            <Slider data-testid="slider-frequency" min={0.1} max={5} step={0.1} value={[frequency]}
              onValueChange={([v]) => { setFrequency(Math.round(v * 10) / 10); reset(); }}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Damping: {damping}
            </label>
            <Slider data-testid="slider-damping" min={0} max={0.5} step={0.01} value={[damping]}
              onValueChange={([v]) => { setDamping(Math.round(v * 100) / 100); reset(); }}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>
          <button data-testid="button-reset-shm" onClick={reset}
            className="w-full py-3 rounded-lg bg-violet-500/20 border border-violet-500/50 text-violet-300 font-mono text-sm uppercase tracking-widest hover:bg-violet-500/30 transition-all">
            Reset
          </button>
        </div>
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={700} height={300} data-testid="canvas-shm"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Period", value: `${period} s`, formula: "T = 1/f" },
          { label: "Angular Freq", value: `${omega} rad/s`, formula: "ω = 2πf" },
          { label: "Equation", value: "x(t) = Ae⁻ᵝᵗcos(ωt)", formula: "Damped SHM" },
        ].map(item => (
          <div key={item.label} className="bg-violet-950/20 border border-violet-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-violet-500 font-mono mb-1">{item.formula}</div>
            <div className="text-lg font-bold text-violet-300 font-mono truncate">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
