import { useState, useRef, useEffect } from "react";
import { Slider } from "@/components/ui/slider";

// ──────────────────────────────────────────────
// PHYSICS REFERENCE
// Ions accelerated through voltage V: qV = ½mv²  →  v = √(2qV/m)
// In magnetic field B (into page), Lorentz force: F = qvB = mv²/r
//   → r = mv/(qB) = (1/B)·√(2mV/q)
// For same charge q: r ∝ √(mV) / B
// Heavier isotopes → larger radius → land further from entry slit
// ──────────────────────────────────────────────

const CANVAS_W = 700;
const CANVAS_H = 380;
const ENTRY_X = 100;  // x of detector/slit line
const ENTRY_Y = 72;   // y of entry slit
const SCALE = 5.5;    // px = SCALE · √(mass · voltage) / bField

const ISO_COLORS = ["#00e5ff", "#a855f7", "#fb923c"];
const ISO_NAMES  = ["¹H  (m)", "²H  (2m)", "³H  (3m)"];

export default function MassSpectrometer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef   = useRef<number>(0);
  const startRef  = useRef<number | null>(null);

  const [voltage,     setVoltage]     = useState(60);
  const [bField,      setBField]      = useState(1.0);
  const [numIsotopes, setNumIsotopes] = useState(2);

  // Compute orbit radius for isotope of given mass multiplier (clamped to canvas)
  const getR = (mass: number) => {
    const r = SCALE * Math.sqrt(mass * voltage) / bField;
    return Math.max(20, Math.min(r, CANVAS_H - ENTRY_Y - 22));
  };

  // Reset animation phase when params change
  useEffect(() => { startRef.current = null; }, [voltage, bField, numIsotopes]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const elapsed = (ts - startRef.current) / 1000;

      const W = CANVAS_W;
      const H = CANVAS_H;
      ctx.clearRect(0, 0, W, H);

      // ── B-field region (right of detector) ──────────────────
      ctx.fillStyle = "rgba(0, 30, 70, 0.22)";
      ctx.fillRect(ENTRY_X, 0, W - ENTRY_X, H);

      // Draw ⊗ symbols (B into page)
      ctx.lineWidth = 1;
      for (let dx = ENTRY_X + 26; dx < W - 14; dx += 40) {
        for (let dy = 18; dy < H - 14; dy += 40) {
          ctx.strokeStyle = "rgba(0,160,255,0.20)";
          ctx.beginPath();
          ctx.arc(dx, dy, 4.5, 0, Math.PI * 2);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(dx - 3, dy - 3); ctx.lineTo(dx + 3, dy + 3);
          ctx.moveTo(dx + 3, dy - 3); ctx.lineTo(dx - 3, dy + 3);
          ctx.stroke();
        }
      }
      ctx.fillStyle = "rgba(0,160,255,0.40)";
      ctx.font = "11px monospace";
      ctx.textAlign = "left";
      ctx.fillText("⊗  B (into page)", ENTRY_X + 16, H - 12);

      // ── Detector / ion-source strip ──────────────────────────
      // Shaded left panel
      const panel = ctx.createLinearGradient(0, 0, ENTRY_X, 0);
      panel.addColorStop(0, "rgba(0,0,0,0)");
      panel.addColorStop(1, "rgba(0,229,255,0.04)");
      ctx.fillStyle = panel;
      ctx.fillRect(0, 0, ENTRY_X, H);

      ctx.strokeStyle = "rgba(0,229,255,0.55)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(ENTRY_X, 0);
      ctx.lineTo(ENTRY_X, H);
      ctx.stroke();

      ctx.fillStyle = "rgba(0,229,255,0.45)";
      ctx.font = "10px monospace";
      ctx.textAlign = "center";
      ctx.fillText("Ion source /", ENTRY_X / 2, H / 2 - 12);
      ctx.fillText("Detector", ENTRY_X / 2, H / 2 + 4);

      // Entry slit (glowing square gap)
      ctx.fillStyle = "rgba(0,229,255,0.9)";
      ctx.fillRect(ENTRY_X - 5, ENTRY_Y - 4, 10, 8);
      ctx.fillStyle = "rgba(0,229,255,0.5)";
      ctx.textAlign = "left";
      ctx.font = "10px monospace";
      ctx.fillText("Entry slit", ENTRY_X + 7, ENTRY_Y + 4);

      // Ion source "gun" lines on left
      for (let i = -2; i <= 2; i++) {
        const ly = ENTRY_Y + i * 14;
        ctx.strokeStyle = "rgba(0,229,255,0.2)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, ly);
        ctx.lineTo(ENTRY_X - 8, ly);
        ctx.stroke();
      }

      // ── Isotope arcs ───────────────────────────────────────────
      // The particle enters at (ENTRY_X, ENTRY_Y) moving rightward (+x).
      // B into page → Lorentz force downward → particle curves downward.
      // Center of circular orbit: (ENTRY_X, ENTRY_Y + r)
      // Angle parametrization: θ from -π/2 (entry) → +π/2 (landing), moving clockwise.
      // At θ = -π/2: position = (ENTRY_X, ENTRY_Y) ✓
      // At θ =  0:   position = (ENTRY_X + r, ENTRY_Y + r) [rightmost]
      // At θ = +π/2: position = (ENTRY_X, ENTRY_Y + 2r)    [landing] ✓

      const PERIOD = 4.2; // seconds per animation cycle
      // Angle sweeps -π/2 → +π/2 in one period
      const phase = (elapsed % PERIOD) / PERIOD; // 0 → 1
      const particleAngle = -Math.PI / 2 + Math.PI * phase;

      for (let iso = 0; iso < numIsotopes; iso++) {
        const mass  = iso + 1;
        const r     = getR(mass);
        const color = ISO_COLORS[iso];

        const orbitCX = ENTRY_X;          // circle center x
        const orbitCY = ENTRY_Y + r;      // circle center y

        // ── Dashed trajectory arc ──
        ctx.beginPath();
        ctx.arc(orbitCX, orbitCY, r, -Math.PI / 2, Math.PI / 2);
        ctx.strokeStyle = `${color}30`;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 5]);
        ctx.stroke();
        ctx.setLineDash([]);

        // ── Landing marker on detector ──
        const landY = ENTRY_Y + 2 * r;
        const landGrd = ctx.createRadialGradient(ENTRY_X, landY, 0, ENTRY_X, landY, 10);
        landGrd.addColorStop(0, color);
        landGrd.addColorStop(1, `${color}00`);
        ctx.beginPath();
        ctx.arc(ENTRY_X, landY, 10, 0, Math.PI * 2);
        ctx.fillStyle = landGrd;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(ENTRY_X, landY, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();

        // Label on detector strip (left of line)
        ctx.fillStyle = color;
        ctx.textAlign = "right";
        ctx.font = "10px monospace";
        ctx.fillText(`m${mass}: Δy=${(2 * r).toFixed(0)}px`, ENTRY_X - 7, landY + 4);

        // Radius label at rightmost point of arc
        ctx.textAlign = "left";
        const lx = orbitCX + r + 7;
        const ly = orbitCY + 3;
        if (lx < W - 50) {
          ctx.fillStyle = `${color}AA`;
          ctx.fillText(`r${mass} = ${r.toFixed(0)}px`, lx, ly);
        }

        // ── Animated particle ──
        const px = orbitCX + r * Math.cos(particleAngle);
        const py = orbitCY + r * Math.sin(particleAngle);

        // Trail (short arc behind particle)
        const trailAngle = particleAngle - 0.45;
        ctx.beginPath();
        ctx.arc(orbitCX, orbitCY, r,
          Math.max(-Math.PI / 2, trailAngle),
          particleAngle);
        ctx.strokeStyle = `${color}55`;
        ctx.lineWidth = 3;
        ctx.stroke();

        // Glow + core
        const grd = ctx.createRadialGradient(px, py, 0, px, py, 15);
        grd.addColorStop(0,   color);
        grd.addColorStop(0.5, `${color}55`);
        grd.addColorStop(1,   `${color}00`);
        ctx.beginPath();
        ctx.arc(px, py, 15, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
      }

      // ── Legend ───────────────────────────────────────────────
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(255,220,80,0.55)";
      ctx.font = "10px monospace";
      ctx.fillText(`V = ${voltage} (arb.)   B = ${bField.toFixed(1)} (arb.)`, ENTRY_X + 14, 20);

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [voltage, bField, numIsotopes]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="space-y-4">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Accelerating Voltage: {voltage} V
            </label>
            <Slider data-testid="slider-ms-voltage"
              min={10} max={200} step={5} value={[voltage]}
              onValueChange={([v]) => setVoltage(v)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>

          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Magnetic Field B: {bField.toFixed(1)}
            </label>
            <Slider data-testid="slider-ms-bfield"
              min={0.3} max={2.0} step={0.1} value={[bField]}
              onValueChange={([v]) => setBField(Math.round(v * 10) / 10)}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>

          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-2 block">
              Isotopes: {numIsotopes}
            </label>
            <div className="flex gap-2">
              {[1, 2, 3].map(n => (
                <button key={n} data-testid={`button-isotopes-${n}`}
                  onClick={() => setNumIsotopes(n)}
                  className={`flex-1 py-2 rounded font-mono text-sm border transition-all
                    ${numIsotopes === n
                      ? "bg-cyan-500/25 border-cyan-400 text-cyan-300"
                      : "border-slate-700 text-slate-500 hover:border-cyan-800"}`}>
                  {n}
                </button>
              ))}
            </div>
          </div>

          {/* Live readout */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-3 space-y-2">
            {Array.from({ length: numIsotopes }, (_, i) => {
              const m = i + 1;
              const r = getR(m);
              return (
                <div key={m} className="flex justify-between text-xs font-mono"
                  style={{ color: ISO_COLORS[i] }}>
                  <span>{ISO_NAMES[i]}</span>
                  <span>r = {r.toFixed(0)} px</span>
                  <span>2r = {Math.round(2 * r)} px</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Canvas */}
        <div className="md:col-span-2">
          <canvas ref={canvasRef} width={CANVAS_W} height={CANVAS_H}
            data-testid="canvas-spectrometer"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>

      {/* Info panels */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Ion Speed",    value: "v = √(2qV/m)", formula: "Energy: qV = ½mv²" },
          { label: "Orbit Radius", value: "r = mv/(qB)",  formula: "Lorentz = centripetal" },
          { label: "Separation",   value: "r ∝ √(mV)/B",  formula: "Heavier → wider arc" },
        ].map(item => (
          <div key={item.label}
            className="bg-cyan-950/20 border border-cyan-900/30 rounded-xl p-4 text-center">
            <div className="text-xs text-cyan-600 font-mono mb-1">{item.formula}</div>
            <div className="text-base font-bold text-cyan-300 font-mono">{item.value}</div>
            <div className="text-xs text-slate-400 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
