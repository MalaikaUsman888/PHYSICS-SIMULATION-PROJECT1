import { useState, useRef, useEffect, useCallback } from "react";
import { Slider } from "@/components/ui/slider";

interface Params {
  velocity: number;
  angle: number;
  gravity: number;
}

function computeResults(p: Params) {
  const rad = (p.angle * Math.PI) / 180;
  const vx  = p.velocity * Math.cos(rad);
  const vy  = p.velocity * Math.sin(rad);
  const T   = (2 * vy) / p.gravity;
  const R   = vx * T;
  const H   = (vy * vy) / (2 * p.gravity);
  return { range: R, maxHeight: H, time: T, vx, vy };
}

// Pick a "nice" step for grid labels
function niceStep(approxStep: number): number {
  const exp = Math.floor(Math.log10(approxStep));
  const frac = approxStep / Math.pow(10, exp);
  const nice = frac < 1.5 ? 1 : frac < 3.5 ? 2 : frac < 7.5 ? 5 : 10;
  return nice * Math.pow(10, exp);
}

export default function ProjectileMotion() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef   = useRef<number>(0);
  const activeRef = useRef(false);       // kill-switch for stale RAF frames

  const [params,    setParams]    = useState<Params>({ velocity: 50, angle: 45, gravity: 9.8 });
  const [results,   setResults]   = useState({ range: 0, maxHeight: 0, time: 0 });
  const [isRunning, setIsRunning] = useState(false);

  // ─────────────────────────────────────────────────────────────────
  // drawScene — takes ALL data as arguments, ZERO captured state.
  // Uses a UNIFORM scale (same px/m for both axes) so the trajectory
  // shape genuinely changes with angle, and the grid labels show
  // the real physical dimensions so velocity/gravity changes are
  // visible via the changing scale.
  // ─────────────────────────────────────────────────────────────────
  const drawScene = useCallback((p: Params, t: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W   = canvas.width;
    const H   = canvas.height;
    const pad = 52;
    ctx.clearRect(0, 0, W, H);

    const res = computeResults(p);
    const rad = (p.angle * Math.PI) / 180;

    // ── Uniform scale: same px-per-metre in x and y ──────────────
    // The trajectory shape now correctly reflects the angle.
    // Velocity / gravity changes → scale changes → grid labels change.
    const drawW = W - pad * 2;
    const drawH = H - pad * 2;
    const scale = Math.min(
      drawW / Math.max(res.range,     0.1),
      drawH / Math.max(res.maxHeight, 0.1) * 0.88,
    );

    // Fixed origin: bottom-left of the axis area
    const ox = pad;
    const oy = H - pad;

    // Convert physics → canvas coords
    const toCanvasX = (x: number) => ox + x * scale;
    const toCanvasY = (y: number) => oy - y * scale;

    // ── Background grid ───────────────────────────────────────────
    const xMax    = res.range     * 1.15;
    const yMax    = res.maxHeight * 1.30;
    const rawStep = Math.max(xMax, yMax) / 5;
    const step    = niceStep(rawStep);

    ctx.lineWidth   = 1;
    ctx.strokeStyle = "rgba(0,255,255,0.10)";
    ctx.font        = "9px monospace";
    ctx.fillStyle   = "rgba(0,255,255,0.40)";
    ctx.textAlign   = "center";

    // Vertical grid + x labels
    for (let x = 0; x <= xMax + step; x += step) {
      const cx = toCanvasX(x);
      if (cx > W - pad + 2) break;
      ctx.beginPath();
      ctx.moveTo(cx, pad);
      ctx.lineTo(cx, oy);
      ctx.stroke();
      if (x > 0) ctx.fillText(`${x}m`, cx, oy + 14);
    }
    // Horizontal grid + y labels
    ctx.textAlign = "right";
    for (let y = 0; y <= yMax + step; y += step) {
      const cy = toCanvasY(y);
      if (cy < pad - 2) break;
      ctx.beginPath();
      ctx.moveTo(ox, cy);
      ctx.lineTo(W - pad, cy);
      ctx.stroke();
      if (y > 0) ctx.fillText(`${y}m`, ox - 4, cy + 3);
    }

    // ── Axes ──────────────────────────────────────────────────────
    ctx.strokeStyle = "rgba(0,255,255,0.45)";
    ctx.lineWidth   = 1.5;
    ctx.textAlign   = "center";
    ctx.beginPath(); ctx.moveTo(ox, pad);  ctx.lineTo(ox, oy);       ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ox, oy);   ctx.lineTo(W - pad, oy);  ctx.stroke();

    // Axis labels
    ctx.fillStyle = "rgba(0,255,255,0.55)";
    ctx.font      = "10px monospace";
    ctx.fillText("Distance (m)", ox + drawW / 2, oy + 28);
    ctx.save();
    ctx.translate(14, oy - drawH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Height (m)", 0, 0);
    ctx.restore();

    // ── Launch angle indicator ────────────────────────────────────
    const vecLen = 38;
    ctx.strokeStyle = "rgba(255,220,50,0.50)";
    ctx.lineWidth   = 1.5;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    ctx.lineTo(ox + Math.cos(rad) * vecLen, oy - Math.sin(rad) * vecLen);
    ctx.stroke();
    ctx.setLineDash([]);

    // ── Full trajectory (dashed) ──────────────────────────────────
    ctx.strokeStyle = "rgba(0,255,255,0.55)";
    ctx.lineWidth   = 2;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    let started = false;
    for (let i = 0; i <= 300; i++) {
      const ts = (res.time / 300) * i;
      const x  = res.vx * ts;
      const y  = res.vy * ts - 0.5 * p.gravity * ts * ts;
      if (y < -0.01) break;
      const cx = toCanvasX(x);
      const cy = toCanvasY(Math.max(y, 0));
      if (!started) { ctx.moveTo(cx, cy); started = true; }
      else           ctx.lineTo(cx, cy);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // ── Peak height dashed guide ──────────────────────────────────
    const peakX = res.vx * (res.time / 2);
    const peakY = res.maxHeight;
    ctx.strokeStyle = "rgba(124,58,237,0.35)";
    ctx.lineWidth   = 1;
    ctx.setLineDash([3, 4]);
    ctx.beginPath();
    ctx.moveTo(toCanvasX(peakX), toCanvasY(peakY));
    ctx.lineTo(toCanvasX(peakX), oy);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(124,58,237,0.70)";
    ctx.font      = "9px monospace";
    ctx.textAlign = "left";
    ctx.fillText(`h=${res.maxHeight.toFixed(1)}m`, toCanvasX(peakX) + 3, toCanvasY(peakY) - 4);

    // ── Animated ball ─────────────────────────────────────────────
    const curT = Math.min(t, res.time);
    const bx   = res.vx * curT;
    const by   = res.vy * curT - 0.5 * p.gravity * curT * curT;

    if (by >= -0.01) {
      const cx  = toCanvasX(bx);
      const cy  = toCanvasY(Math.max(by, 0));
      const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 18);
      grd.addColorStop(0,   "rgba(0,255,255,1)");
      grd.addColorStop(0.5, "rgba(0,200,255,0.55)");
      grd.addColorStop(1,   "rgba(0,80,200,0)");
      ctx.beginPath(); ctx.arc(cx, cy, 18, 0, Math.PI * 2);
      ctx.fillStyle = grd; ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy,  7, 0, Math.PI * 2);
      ctx.fillStyle = "#00ffff"; ctx.fill();
    }

    // ── Scale indicator ───────────────────────────────────────────
    ctx.fillStyle = "rgba(0,255,255,0.40)";
    ctx.font      = "9px monospace";
    ctx.textAlign = "left";
    ctx.fillText(`scale: 1 grid = ${step} m`, pad + 4, pad - 4);
  }, []); // truly stable — only uses arguments

  // ── Redraw whenever params change ─────────────────────────────
  useEffect(() => {
    activeRef.current = false;
    cancelAnimationFrame(animRef.current);
    setIsRunning(false);

    const res = computeResults(params);
    setResults({
      range:     Math.round(res.range * 10) / 10,
      maxHeight: Math.round(res.maxHeight * 100) / 100,
      time:      Math.round(res.time * 100) / 100,
    });
    drawScene(params, 0);
  }, [params, drawScene]);

  // ── Launch handler ────────────────────────────────────────────
  const handleLaunch = () => {
    const snap = { ...params };        // snapshot at click-time
    const res  = computeResults(snap);

    cancelAnimationFrame(animRef.current);
    activeRef.current = true;
    setIsRunning(true);

    let startTime: number | null = null;
    const animate = (ts: number) => {
      if (!activeRef.current) return;
      if (!startTime) startTime = ts;
      const elapsed = (ts - startTime) / 1000;
      drawScene(snap, elapsed);
      if (elapsed < res.time + 0.05) {
        animRef.current = requestAnimationFrame(animate);
      } else {
        activeRef.current = false;
        setIsRunning(false);
        drawScene(snap, res.time);
      }
    };
    animRef.current = requestAnimationFrame(animate);
  };

  const r = params;
  const vx = (r.velocity * Math.cos(r.angle * Math.PI / 180)).toFixed(1);
  const vy = (r.velocity * Math.sin(r.angle * Math.PI / 180)).toFixed(1);

  return (
    <div className="space-y-4">
      {/* ── Main layout: stacks on mobile, side-by-side on md+ ── */}
      <div className="flex flex-col md:flex-row gap-4">
        {/* Sliders */}
        <div className="flex flex-col gap-3 md:w-56 shrink-0">
          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-1.5 block">
              Velocity: {params.velocity} m/s
            </label>
            <Slider data-testid="slider-velocity"
              min={1} max={200} step={1} value={[params.velocity]}
              onValueChange={([v]) => setParams(p => ({ ...p, velocity: v }))}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>

          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-1.5 block">
              Angle: {params.angle}°
            </label>
            <Slider data-testid="slider-angle"
              min={1} max={89} step={1} value={[params.angle]}
              onValueChange={([v]) => setParams(p => ({ ...p, angle: v }))}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>

          <div>
            <label className="text-xs text-cyan-400 font-mono uppercase tracking-widest mb-1.5 block">
              Gravity: {params.gravity} m/s²
            </label>
            <Slider data-testid="slider-gravity"
              min={0.5} max={25} step={0.1} value={[params.gravity]}
              onValueChange={([v]) => setParams(p => ({ ...p, gravity: Math.round(v * 10) / 10 }))}
              className="[&_[role=slider]]:bg-cyan-400" />
          </div>

          <button data-testid="button-launch"
            onClick={handleLaunch}
            disabled={isRunning}
            className="w-full py-2.5 rounded-lg bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-mono text-sm uppercase tracking-widest hover:bg-cyan-500/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all">
            {isRunning ? "Flying…" : "▶ Launch"}
          </button>

          {/* Computed components */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-2.5 space-y-1 text-xs font-mono text-slate-400">
            <div>vₓ = {vx} m/s</div>
            <div>vᵧ = {vy} m/s</div>
            <div>g  = {params.gravity} m/s²</div>
          </div>
        </div>

        {/* Canvas — takes remaining width */}
        <div className="flex-1 min-w-0">
          <canvas ref={canvasRef} width={640} height={320}
            data-testid="canvas-projectile"
            className="w-full rounded-xl border border-cyan-900/40 bg-[#020818]" />
        </div>
      </div>

      {/* ── Results row ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { label: "Range",       value: `${results.range} m`,     formula: "R = v₀²sin2θ / g" },
          { label: "Max Height",  value: `${results.maxHeight} m`, formula: "h = v₀²sin²θ / 2g" },
          { label: "Flight Time", value: `${results.time} s`,      formula: "T = 2v₀sinθ / g"   },
        ].map(item => (
          <div key={item.label}
            className="bg-cyan-950/20 border border-cyan-900/30 rounded-xl p-3 text-center">
            <div className="text-xs text-cyan-600 font-mono mb-0.5 leading-tight">{item.formula}</div>
            <div className="text-lg font-bold text-cyan-300 font-mono leading-tight">{item.value}</div>
            <div className="text-xs text-slate-400 mt-0.5">{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
