import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Atom, Waves, Activity, FlaskConical, Zap, ArrowLeft, Sun, RotateCcw, Orbit } from "lucide-react";
import ProjectileMotion from "./simulations/ProjectileMotion";
import SHM from "./simulations/SHM";
import MassSpectrometer from "./simulations/MassSpectrometer";
import Wave from "./simulations/Wave";
import Circuit from "./simulations/Circuit";
import ElectronOrbital from "./simulations/ElectronOrbital";
import LightOptics from "./simulations/LightOptics";
import OrbitalPrecession from "./simulations/OrbitalPrecession";

type SimKey =
  | "projectile"
  | "shm"
  | "spectrometer"
  | "wave"
  | "circuit"
  | "orbital"
  | "optics"
  | "precession";

interface SimCard {
  key: SimKey;
  title: string;
  description: string;
  icon: React.ReactNode;
  accent: string;
  border: string;
  glow: string;
  tag: string;
}

const SIMS: SimCard[] = [
  {
    key: "projectile",
    title: "Projectile Motion",
    description: "Ballistic trajectory under gravity with configurable velocity, angle and gravitational field.",
    icon: <RotateCcw size={28} />,
    accent: "text-cyan-400",
    border: "border-cyan-900/40 hover:border-cyan-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(0,255,255,0.15)]",
    tag: "Mechanics",
  },
  {
    key: "shm",
    title: "Simple Harmonic Motion",
    description: "Spring-mass oscillator with damping. Real-time position wave graph.",
    icon: <Activity size={28} />,
    accent: "text-violet-400",
    border: "border-violet-900/40 hover:border-violet-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(124,58,237,0.2)]",
    tag: "Oscillations",
  },
  {
    key: "spectrometer",
    title: "Mass Spectrometer",
    description: "Ions accelerated by voltage, separated by magnetic field. Identify isotopes by orbit radius.",
    icon: <FlaskConical size={28} />,
    accent: "text-cyan-300",
    border: "border-cyan-900/40 hover:border-cyan-400/60",
    glow: "hover:shadow-[0_0_28px_rgba(0,255,255,0.12)]",
    tag: "E&M / Atomic",
  },
  {
    key: "wave",
    title: "Wave Simulation",
    description: "Traveling waves with interference patterns. Toggle two-source superposition.",
    icon: <Waves size={28} />,
    accent: "text-teal-400",
    border: "border-teal-900/40 hover:border-teal-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(20,184,166,0.2)]",
    tag: "Waves",
  },
  {
    key: "circuit",
    title: "Electric Circuit",
    description: "Animated circuit with flowing current particles. Ohm's Law and power calculations.",
    icon: <Zap size={28} />,
    accent: "text-yellow-400",
    border: "border-yellow-900/40 hover:border-yellow-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(234,179,8,0.2)]",
    tag: "Electricity",
  },
  {
    key: "orbital",
    title: "Electron Orbital",
    description: "Quantum electron orbital visualization. s, p, d shells with probability clouds.",
    icon: <Atom size={28} />,
    accent: "text-cyan-400",
    border: "border-cyan-900/40 hover:border-cyan-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(0,255,255,0.15)]",
    tag: "Quantum",
  },
  {
    key: "optics",
    title: "Reflection & Refraction",
    description: "Snell's Law with real-time ray bending. Observe total internal reflection.",
    icon: <Sun size={28} />,
    accent: "text-emerald-400",
    border: "border-emerald-900/40 hover:border-emerald-500/60",
    glow: "hover:shadow-[0_0_28px_rgba(52,211,153,0.2)]",
    tag: "Optics",
  },
  {
    key: "precession",
    title: "Orbital Precession",
    description: "GR-corrected gravity causes orbits to precess. Watch Mercury's rosette unfold.",
    icon: <Orbit size={28} />,
    accent: "text-violet-300",
    border: "border-violet-900/40 hover:border-violet-400/60",
    glow: "hover:shadow-[0_0_28px_rgba(167,139,250,0.18)]",
    tag: "Relativity",
  },
];

const SIM_COMPONENTS: Record<SimKey, React.ComponentType> = {
  projectile:  ProjectileMotion,
  shm:         SHM,
  spectrometer: MassSpectrometer,
  wave:        Wave,
  circuit:     Circuit,
  orbital:     ElectronOrbital,
  optics:      LightOptics,
  precession:  OrbitalPrecession,
};

export default function Home() {
  const [selected, setSelected] = useState<SimKey | null>(null);

  const activeSim       = selected ? SIMS.find(s => s.key === selected) : null;
  const ActiveComponent = selected ? SIM_COMPONENTS[selected] : null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-slate-800/60 bg-background/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
              <Atom size={16} className="text-cyan-400" />
            </div>
            <span className="font-mono text-sm font-semibold tracking-wider text-slate-200">
              PHYSICS LAB SIMULATOR
            </span>
          </div>
          {selected && (
            <button
              data-testid="button-back"
              onClick={() => setSelected(null)}
              className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors font-mono text-sm"
            >
              <ArrowLeft size={15} />
              All Simulations
            </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-6 sm:py-10">
        <AnimatePresence mode="wait">
          {!selected ? (
            <motion.div
              key="grid"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-center mb-12">
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 }}
                  className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-300 to-violet-400 mb-4 font-mono"
                >
                  Physics Lab
                </motion.h1>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.12 }}
                  className="text-slate-400 text-lg font-mono max-w-xl mx-auto"
                >
                  Select a simulation to explore. Adjust parameters in real time.
                </motion.p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {SIMS.map((sim, i) => (
                  <motion.button
                    key={sim.key}
                    data-testid={`card-sim-${sim.key}`}
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.055 }}
                    onClick={() => setSelected(sim.key)}
                    className={`group text-left p-6 rounded-2xl bg-card border ${sim.border} ${sim.glow} transition-all duration-300 cursor-pointer`}
                  >
                    <div className={`mb-4 ${sim.accent} transition-transform duration-300 group-hover:scale-110 origin-left`}>
                      {sim.icon}
                    </div>
                    <div className="mb-1">
                      <span className={`text-xs font-mono uppercase tracking-widest ${sim.accent} opacity-70`}>
                        {sim.tag}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-100 mb-2 leading-tight">{sim.title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{sim.description}</p>
                    <div className={`mt-4 text-xs font-mono ${sim.accent} opacity-0 group-hover:opacity-80 transition-opacity`}>
                      Open simulation →
                    </div>
                  </motion.button>
                ))}
              </div>

              <div className="mt-12 grid grid-cols-3 gap-6 max-w-lg mx-auto">
                {[
                  { n: "8", label: "Simulations" },
                  { n: "∞", label: "Parameters" },
                  { n: "60", label: "FPS Canvas" },
                ].map(item => (
                  <div key={item.label} className="text-center">
                    <div className="text-3xl font-black text-cyan-400 font-mono">{item.n}</div>
                    <div className="text-xs text-slate-500 mt-1 font-mono uppercase tracking-wider">{item.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={selected}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.25 }}
            >
              <div className="mb-8">
                <div className={`text-xs font-mono uppercase tracking-widest mb-2 ${activeSim?.accent}`}>
                  {activeSim?.tag}
                </div>
                <h2 className="text-3xl font-black text-slate-100 font-mono">{activeSim?.title}</h2>
                <p className="text-slate-400 text-sm mt-1">{activeSim?.description}</p>
              </div>

              <div className={`rounded-2xl border ${activeSim?.border} bg-card p-3 sm:p-6 overflow-x-hidden transition-all duration-300`}>
                {ActiveComponent && <ActiveComponent />}
              </div>

              <div className="mt-8">
                <div className="text-xs text-slate-600 font-mono mb-4 uppercase tracking-widest">Other Simulations</div>
                <div className="flex gap-3 flex-wrap">
                  {SIMS.filter(s => s.key !== selected).map(sim => (
                    <button
                      key={sim.key}
                      data-testid={`chip-sim-${sim.key}`}
                      onClick={() => setSelected(sim.key)}
                      className={`px-4 py-2 rounded-full border text-xs font-mono ${sim.border} ${sim.accent} hover:bg-white/5 transition-all`}
                    >
                      {sim.title}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
